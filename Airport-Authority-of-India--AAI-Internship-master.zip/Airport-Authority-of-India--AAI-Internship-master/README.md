# AAI

## Airport Authority of India (AAI)

## Data Analysis and Prediction on MIDT

## Python, Sklearn, Matplotlib, Numpy, Pandas.

This project was done for completion of internship at Airport Authority Of India. It involved analysis of data provided by CPMA department of AAI. This data was of passengers, freight flights and flight movements of All India and Delhi region of each month since 2018. Our objective was to find patterns and use them to predict the data for upcoming years using predictive models.
